# MyOS
Creating Simple Operating System
 
You have created a simple operating system on a virtual environment for a version of Linux Mint that contains the Welcome screen, the Authentication screen, output screen and  Applications screen consisting of the following applications:

1- Apply age account
2- Apply the calculation of the sum of the matrix elements and the largest component
3- An account for power

The OS contains of:
1-Boot loader
2-kernel
3-User Interface
