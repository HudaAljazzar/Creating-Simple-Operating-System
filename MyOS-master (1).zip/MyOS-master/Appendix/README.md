This Folder contains:
1- The required report that contains the last step analysis (user interface),
challenges and difficulties faced by the team and the skills acquired after 
the establishment of the operating system and the tools used in building 
the operating system


2- It contains the site that was created on the Google site
